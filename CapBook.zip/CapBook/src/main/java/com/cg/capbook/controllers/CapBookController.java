package com.cg.capbook.controllers;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.cg.capbook.beans.User;
import com.cg.capbook.exceptions.IncorrectPasswordException;
import com.cg.capbook.exceptions.UserDetailsNotFoundException;
import com.cg.capbook.services.UserServices;

@RestController
@CrossOrigin
public class CapBookController {
	@Autowired 
	private UserServices userServices;

	@RequestMapping(value="/register", method=RequestMethod.POST, consumes=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<String> registerUserAction(@RequestBody User user) {
		userServices.registerUser(user);
		return new ResponseEntity<String>("User successfully added", HttpStatus.OK);
	}

	@RequestMapping(value="/getUserDetails",method=RequestMethod.GET, produces=MediaType.APPLICATION_JSON_VALUE,
			headers="Accept=application/json")
	public ResponseEntity<User> getUserAction(@RequestParam("userId") int userId ) throws UserDetailsNotFoundException {
		User user=userServices.getUserDetails(userId);
		return new ResponseEntity<User>(user, HttpStatus.OK);
	}
	@RequestMapping(value="/editUserDetails",method=RequestMethod.POST,consumes=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<User> editUserAction(@RequestBody User user) {
		user=userServices.editUserDetails(user);
		return new ResponseEntity<User>(user, HttpStatus.OK);
	}
	@RequestMapping(value="/deleteUserDetails",method=RequestMethod.DELETE)
	public ResponseEntity<String> deleteUserAction(@RequestParam("userId") int userId ) throws UserDetailsNotFoundException {
		userServices.deleteUserAccount(userId);
		return new ResponseEntity<String>("User details have been deleted successfully",HttpStatus.OK);
	}
	@RequestMapping(value="/login", method=RequestMethod.POST,consumes=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<String> loginUserAction(@RequestParam("emailId") String emailId, @RequestParam("password") String password) throws IncorrectPasswordException{
		userServices.loginUser(emailId, password);
		return new ResponseEntity<String>("Login successful",HttpStatus.OK);
	}
}
